# Test Evidence Screenshots

This folder contains selected execution evidence used in the portfolio project.

- `search_negative.png` — negative search / no-results behavior
- `cart_quantity_calculation.jpg` — quantity 2 with updated subtotal, tax, and total
- `checkout_shipping_bug.png` — checkout shipping inconsistency evidence
- `order_placed.png` — successful dummy order confirmation and order ID
- `login_required_validation.png` — required-field validation on login
