# Test Execution Report

## Project

**E-Commerce Web Application — Manual QA Testing**  
**Application:** QATools Playground — Shop  
**URL:** https://playground.qatools.dev/products  
**Execution Type:** Manual Functional Testing  
**Execution Date:** November 2026

## Objective

Validate the major customer-facing workflows of the demo e-commerce application and document functional behavior, calculation accuracy, form validation, end-to-end checkout behavior, and observable defects.

## Scope

Testing included search, filters, sorting, product details, availability, pagination, wishlist, cart, authentication, checkout, shipping, payment, review, order placement, and post-order state.

## Execution Summary

| Metric | Count |
| --- | ---: |
| Total Designed Test Cases | 43 |
| Passed | 39 |
| Failed | 2 |
| Blocked | 2 |
| Not Run | 0 |
| Executed Cases | 41 |
| Pass Rate of Executed Cases | 95.1% |

## Failed Test Cases

### TC-SEARCH-005 — Search with leading/trailing spaces

**Expected:** Searching with surrounding whitespace should return the same matching product as the trimmed keyword, based on the provisional UX expectation used for the test.

**Actual:** A leading-space search for `Watch` returned `0 of 0 products` and displayed `No products match your filters.`

**Assessment:** Failed test case, but not opened as a confirmed defect because trimming behavior was not specified in available requirements.

### TC-SHIP-001 — Shipping fee calculation

**Expected:** The displayed shipping charge and total should reflect the selected shipping method. Standard is labelled free, Express +$9.99, and Overnight +$19.99.

**Actual:** Shipping remained $5.99 and total remained $27.58 when switching between all three options.

**Assessment:** Confirmed defect and documented as `BUG-001`.

## Blocked Test Cases

Two product-variant exploratory cases were blocked pending requirements clarification:

- Whether selecting a color should update the main product image.
- Whether the Specs section should reflect the actively selected color instead of the product default.

The observations were documented but intentionally not classified as defects.

## Key Results

- Search functionality passed for matching, non-matching, case-insensitive, partial-keyword, and special-character scenarios.
- Category and price filters behaved as expected in executed cases.
- Price sorting worked correctly both within and across pagination pages.
- Out-of-stock products could not be added to cart.
- Wishlist add/remove flows passed.
- Cart quantity changes correctly updated subtotal, tax, and total.
- Required shipping and payment fields blocked incomplete submissions.
- Demo authentication succeeded using the site's provided account.
- Cash on delivery and dummy PayPal correctly hid card fields.
- Review page retained shipping, payment, and product details.
- The dummy order was successfully placed and returned an order ID.
- The purchased item was removed from the cart after order completion.

## Defect Summary

| Bug ID | Title | Severity | Priority | Status |
| --- | --- | --- | --- | --- |
| BUG-001 | Shipping cost and total do not update when shipping method changes | High | High | Open |

## Conclusion

The tested e-commerce application successfully handled most core user journeys. The executed test pass rate was **95.1%**. One high-impact checkout pricing inconsistency was reproducible and documented as an open defect. Two exploratory variant behaviors require product-requirement clarification before defect classification.
