# Bug Reports

## BUG-001 — Shipping cost and total do not update when shipping method changes

**Module:** Checkout / Shipping  
**Severity:** High  
**Priority:** High  
**Status:** Open  
**Environment:** QATools Playground Shop — Checkout

### Preconditions

- Sign in using the site's demo account.
- Add one `Cotton T-Shirt` priced at `$19.99` to the cart.
- Proceed to `Checkout > Shipping`.

### Steps to Reproduce

1. Observe that `Standard (5–7 days, free)` is selected.
2. Check the `Shipping` and `Total` values in the order summary.
3. Select `Express (+$9.99)`.
4. Check the order summary again.
5. Select `Overnight (+$19.99)`.
6. Check the order summary again.
7. Re-select `Standard` and compare all displayed values.

### Expected Result

- Standard shipping marked as free should display a `$0` shipping charge.
- Express should update the shipping amount to reflect `+$9.99`.
- Overnight should update the shipping amount to reflect `+$19.99`.
- The order total should update when the selected shipping option changes, unless another pricing rule is clearly disclosed.

### Actual Result

- Shipping remained `$5.99` for Standard, Express, and Overnight.
- Total remained `$27.58` for all three methods.
- Standard was visibly labelled as free while the order summary charged `$5.99`.
- Subtotal `$19.99` + tax `$1.60` + shipping `$5.99` correctly equals `$27.58`; therefore the arithmetic itself is not the defect.

### User Impact

The customer cannot reliably confirm the shipping fee associated with the selected delivery method before placing an order. This can cause pricing confusion and reduce trust in checkout totals.

### Evidence

See:

- `screenshots/checkout_shipping_bug.png`

### Follow-up

After a fix, retest all three shipping methods and verify both `Shipping` and `Total` values. Tax behavior should be validated separately against documented tax rules.
